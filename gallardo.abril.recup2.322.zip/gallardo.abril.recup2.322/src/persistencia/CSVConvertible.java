
package persistencia;


public interface CSVConvertible {
    String toCSV();
}
