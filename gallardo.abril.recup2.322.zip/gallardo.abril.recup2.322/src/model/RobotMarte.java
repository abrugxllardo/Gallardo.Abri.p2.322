
package model;

import java.io.Serializable;
import persistencia.CSVConvertible;


public class RobotMarte implements Serializable, Comparable<RobotMarte>, CSVConvertible{
    private static final long serialVersionUID = 1L;

    private final int id;
    private final String nombre;
    private final TipoRobot tipo;
    private final int nivelBateria;
    private final int anioFabricacion;
    private final double kmRecorridos;

    public RobotMarte(int id, String nombre, TipoRobot tipo, int nivelBateria, int anioFabricacion, double kmRecorridos) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.nivelBateria = nivelBateria;
        this.anioFabricacion = anioFabricacion;
        this.kmRecorridos = kmRecorridos;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoRobot getTipo() {
        return tipo;
    }

    public int getNivelBateria() {
        return nivelBateria;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }
   
    public double getKmRecorridos() {
        return kmRecorridos;
    }
    
     @Override
    public int compareTo(RobotMarte o) {
        return Integer.compare(this.id, o.id);
    }
    
      public static String toHeader(){
        return "Id, Nombre, Tipo, Nivel Bateria, Año Frabricacion, KM Recorridos";
    }
      
      public static RobotMarte fromCsv(String criaturaCsv){
       String[] atributos = criaturaCsv.split(", ");
       if(criaturaCsv == null){
           throw new IllegalArgumentException("Criatura invalida");
       }
       int id = Integer.parseInt(atributos[0]);
        String nombre = atributos[1];        
        TipoRobot tipo = TipoRobot.valueOf(atributos[2].trim());
        int nivelBateria = Integer.parseInt(atributos[3]);      
        int anioFabricacion = Integer.parseInt(atributos[4]);
        double kmRecorridos = Double.parseDouble(atributos[5]);
        
        return new RobotMarte(id, nombre, tipo, nivelBateria, anioFabricacion, kmRecorridos);
   } 
      
       @Override
    public String toString() {
        return "Robot ->" + id + ", "+ nombre + ", " + tipo + ", " + nivelBateria + ", " + anioFabricacion + ", " + kmRecorridos;
    }
    
     @Override
     public String toCSV(){
        return id + ", " + nombre + ", " + tipo + ", " + nivelBateria + ", " + anioFabricacion + ", " + kmRecorridos;
    }

}
