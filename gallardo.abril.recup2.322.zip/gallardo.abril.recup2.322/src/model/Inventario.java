
package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import persistencia.CSVConvertible;


public class Inventario<T extends CSVConvertible> implements Almacenable<T>{
    
    private List<T> robots = new ArrayList<>();
    
    @Override
    public void agregar(T robot) {
        if(robot == null){
            throw new IllegalArgumentException("Elemento nulo");
        }
        robots.add(robot);
    }
    
    @Override
    public void eliminarSegun(Predicate<T> criterio){
        for (T  robot : robots) {
            if (criterio.test(robot)){
                robots.remove(robot);
            }
        }
    }    
    
     @Override
    public List<T> obtenerTodos() {
        return new ArrayList<>(robots);
}
    
    @Override
    public T buscar(Predicate<T> criterio) {
        for (T  robot : robots) {
            if (criterio.test(robot)){
                return robot;
            }
        }
        return null;
    }
    
    @Override
     public void ordenar(Comparator<T> cmp){
        robots.sort(cmp);
    }
    
    @Override
     public void ordenar(){
        robots.sort((Comparator<T>) Comparator.naturalOrder());
    }
     
    @Override
    public List<T> filtrar(Predicate<T> criterio) {
       List<T> resultado = new ArrayList<>();

       for (T  robot : robots) {
           if (criterio.test(robot)){
               resultado.add(robot);
           }
       }
       return resultado;
   }
    
     @Override
    public List<T> transformar(Function<T,T> transformacion) {
        List<T> resultado = new ArrayList<>();

        for (T robot : robots) {
            T nuevo = transformacion.apply(robot);
            resultado.add(nuevo);
        }

        return resultado;
    }
    
    @Override
    public int contar(Predicate<T> criterio){
        
        int contador = 0;
        for (T  robot : robots) {
           if (criterio.test(robot)){
               contador++;
           }
       }
        
        return contador;
    }

    @Override
    public void guardarEnBinario(String ruta) throws Exception {
        try(ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(ruta))){
            
            serializador.writeObject(robots);
            
        }catch(IOException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws Exception {
        robots.clear();
        try(ObjectInputStream deserializador = new ObjectInputStream(new FileInputStream(ruta))){
            robots = (List<T>) deserializador.readObject();
        }catch(IOException | ClassNotFoundException e){
            System.out.println(e.getMessage());
        }    
    
    }

    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(ruta))){
            writer.write(RobotMarte.toHeader());
            writer.newLine();
            
            for(T e : robots){
                if(!(e instanceof CSVConvertible)){
                    throw new IllegalArgumentException("Error");
                }
                writer.write(e.toCSV());
                writer.newLine();
            }
            
            
        }catch(IOException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
        try(BufferedReader reader = new BufferedReader(new FileReader(ruta))){
                String linea;
                reader.readLine();

                while((linea = reader.readLine()) != null){
                    robots.add(fromCSV.apply(linea));
                }

            }catch(IOException ex){
                System.out.println(ex.getMessage());
            }
    }

}
