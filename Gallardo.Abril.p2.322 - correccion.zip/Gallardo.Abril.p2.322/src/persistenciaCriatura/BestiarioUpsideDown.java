
package persistenciaCriatura;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import model.Criatura;

public class BestiarioUpsideDown<T extends CSVSerializable>{
    
    private List<T> bestias = new ArrayList<>();
    
    public void agregar(T bestia) {
        if(bestia == null){
            throw new NullPointerException("Elemento nulo");
        }
        bestias.add(bestia);
    }
    
    public void validarIndice(int indice){
        if( indice < 0 || indice >= bestias.size()){
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }
    
    public T obtener(int indice) {
        validarIndice(indice);
        return bestias.get(indice);
    }

    public void eliminar(int indice) {
        validarIndice(indice);
        bestias.remove(indice);
    }
    
    public void paraCadaElemento(Consumer<T> accion) {
        for(T bestia : bestias){
            accion.accept(bestia);
        }
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> resultado = new ArrayList<>();

        for (T  bestia : bestias) {
            if (criterio.test(bestia)){
                resultado.add(bestia);
            }
        }
        return resultado;
    }
    
    public void ordenar(Comparator<? super T> cmp){
        bestias.sort(cmp);
    }
    
     public void ordenar(){
        bestias.sort((Comparator<T>) Comparator.naturalOrder());
    }
     
     
    public void guardarEnCsv(String path) throws IOException{
        
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(path))){
            writer.write(Criatura.toHeaderRow());
            writer.newLine();
            
            for(T e : bestias){
                writer.write(e.toCsv());
                writer.newLine();
            }
            
            
        }catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    public void cargarDesdeCSV(String path, Function<String, T> transformacion) throws IOException{        
        try(BufferedReader reader = new BufferedReader(new FileReader(path))){
            String linea;
            reader.readLine();
            
            while((linea = reader.readLine()) != null){
                bestias.add(transformacion.apply(linea));
            }
            
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    public void guardarEnArchivo(String path) throws IOException{
        
        try(ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))){
            
            serializador.writeObject(bestias);
            
        }catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    public void cargarDesdeArchivo(String path)throws IOException, ClassNotFoundException{        
        bestias.clear();
        try(ObjectInputStream deserializador = new ObjectInputStream(new FileInputStream(path))){
            bestias = (List<T>) deserializador.readObject();
        }catch(IOException | ClassNotFoundException e){
            System.out.println(e.getMessage());
        }
    }
    
    
    

}
