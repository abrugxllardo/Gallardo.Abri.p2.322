
package model;

import java.io.Serializable;
import java.util.Objects;
import persistenciaCriatura.CSVSerializable;


public class Criatura implements Comparable<Criatura>, CSVSerializable{
    private static final long serialVersionUID = 1L;


    private int id;
    private String nombre;
    private String origen;
    private TipoCriatura tipo;


    public Criatura(int id, String nombre, String origen, TipoCriatura tipo) {
    this.id = id;
    this.nombre = nombre;
    this.origen = origen;
    this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getOrigen() {
        return origen;
    }

    public TipoCriatura getTipo() {
        return tipo;
    }
    
    @Override
    public int compareTo(Criatura o) {
        return Integer.compare(this.id, o.id);
    }
    
    @Override
     public String toCsv(){
        return id + ", " + nombre + ", " + origen + ", " + tipo;
    }
    
    public static Criatura fromCsv(String criaturaCsv){
       String[] atributos = criaturaCsv.split(",");
       if(criaturaCsv == null){
           throw new IllegalArgumentException("Criatura invalida");
       }
       int id = Integer.parseInt(atributos[0]);
        String nombre = atributos[1];
        String origen = atributos[2];
        TipoCriatura tipo = TipoCriatura.valueOf(atributos[3].trim());
        
        return new Criatura(id, nombre, origen, tipo);
   } 
    
   @Override
    public boolean equals(Object o){
        if(this == o){
            return true;
        }
        if(!(o instanceof Criatura)){
            return false;
        }
        Criatura criatura = (Criatura) o;
        return id == criatura.id && Objects.equals(nombre, criatura.nombre) && Objects.equals(origen, criatura.origen) && tipo == criatura.tipo;
    }

    public static String toHeaderRow(){
        return "Id, Nombre, Origen, Tipo";
    }

    @Override
    public String toString() {
        return "Criatura ->" + id + ", "+ nombre + "," + origen + "," + tipo;
    }
    
    
}
