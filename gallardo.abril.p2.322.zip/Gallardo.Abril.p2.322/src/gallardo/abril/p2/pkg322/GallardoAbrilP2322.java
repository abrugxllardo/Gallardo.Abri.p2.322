
package gallardo.abril.p2.pkg322;

import java.io.IOException;
import persistenciaCriatura.BestiarioUpsideDown;
import model.Criatura;
import model.TipoCriatura;


public class GallardoAbrilP2322 {

    
    public static void main(String[] args) {
        
            BestiarioUpsideDown<Criatura> bestiario = new BestiarioUpsideDown<>();
            bestiario.agregar(new Criatura(1, "Demogorgon", "Upside Down",
            TipoCriatura.DEMOGORGON));
            bestiario.agregar(new Criatura(2, "Demodog Juvenil", "Bosque de Hawkins",
            TipoCriatura.DEMODOG));
            bestiario.agregar(new Criatura(3, "Shadow Tendril", "Dimensión Principal",
            TipoCriatura.SHADOW_MONSTER));
            bestiario.agregar(new Criatura(4, "Mind Flayer Spawn", "Upside Down",
            TipoCriatura.MIND_FLAYER_MINION));
            bestiario.agregar(new Criatura(5, "Murciélago del Upside Down", "Cueva Oscura", TipoCriatura.MURCIELAGO));
            System.out.println("Criaturas:");
            bestiario.paraCadaElemento(c -> System.out.println(c));
            System.out.println("\nCriaturas tipo DEMODOG:");
            bestiario.filtrar(c -> c.getTipo() == TipoCriatura.DEMODOG).forEach(c -> System.out.println(c));
            System.out.println("\nCriaturas que contienen 'shadow':");
            bestiario.filtrar(c -> c.getNombre().toLowerCase().contains("shadow")).forEach(c -> System.out.println(c));
            System.out.println("\nCriaturas ordenadas por ID:");
            bestiario.ordenar();
            bestiario.paraCadaElemento(c -> System.out.println(c));
            System.out.println("\nCriaturas ordenadas por nombre:");
            bestiario.ordenar();
            bestiario.paraCadaElemento(c -> System.out.println(c));
            bestiario.guardarEnArchivo("src/resources/criaturas.csv");
                        
            BestiarioUpsideDown<Criatura> cargado = new BestiarioUpsideDown<>();
            cargado.cargarDesdeArchivo("src/resources/criaturas.csv");
            System.out.println("\nCriaturas cargadas desde archivo binario:");
            cargado.paraCadaElemento(c -> System.out.println(c));
            bestiario.guardarEnCsv("src/resources/criaturas.csv");
            cargado.cargarDesdeCSV("src/resources/criaturas.csv");
            System.out.println("\nCriaturas cargadas desde archivo CSV:");
            cargado.paraCadaElemento(c -> System.out.println(c));
            
    }
    
}
