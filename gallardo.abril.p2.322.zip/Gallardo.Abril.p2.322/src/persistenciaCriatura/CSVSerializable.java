
package persistenciaCriatura;

public interface CSVSerializable {
    public String toCsv();
}
