
package persistenciaCriatura;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import model.Criatura;
import persistenciaCriatura.CSVSerializable;

public class BestiarioUpsideDown<T extends CSVSerializable & Serializable> implements Serializable{
private static final long serialVersionUID = 1L;
    
    private final List<T> bestias = new ArrayList<>();
    
    public void agregar(T bestia) {
        bestias.add(bestia);
    }

    public T obtener(int indice) {
        return bestias.get(indice);
    }

    public T eliminar(int indice) {
        return bestias.remove(indice);
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> resultado = new ArrayList<>();

        for (T  bestia : bestias) {
            if (criterio.test(bestia)){
                resultado.add(bestia);
            }
        }
        return resultado;
    }
    
    
    private List<T> copiarLista(){
        return new ArrayList<>(bestias);
    }
    
    private List<T> copiaOrdenada(Comparator<? super T> cmp){
        List<T>  copia = copiarLista();
        copia.sort(cmp);
        
        return copia;
    }
    
    public Iterator<T> ordenar(){
        
        if(!bestias.isEmpty() && bestias.get(0) instanceof Comparable){
            return ordenar((Comparator<T>)Comparator.naturalOrder());
        }
        return copiarLista().iterator();
    }
    
     public Iterator<T> ordenar(Comparator<? super T> cmp){
        return copiaOrdenada(cmp).iterator();
    }
     
     
    public void guardarEnCsv(String path){
        
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(path))){
            writer.write(Criatura.toHeaderRow());
            writer.newLine();
            
            for(T e : bestias){
                writer.write(e.toCsv());
                writer.newLine();
            }
            
            
        }catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    public List<Criatura> cargarDesdeCSV(String path){
        List<Criatura> productos = new ArrayList<>();
        
        try(BufferedReader reader = new BufferedReader(new FileReader(path))){
            String linea;
            reader.readLine();
            
            while((linea = reader.readLine()) != null){
                productos.add(Criatura.fromCsv(linea));
            }
            
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }
        
        return productos;
    }
    
    public void guardarEnArchivo(String path){
        
        try(ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))){
            
            serializador.writeObject(bestias);
            
        }catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    public List<Criatura> cargarDesdeArchivo(String path){
        List<Criatura> lista = null;
        
        try(ObjectInputStream deserializador = new ObjectInputStream(new FileInputStream(path))){
            lista = (List<Criatura>) deserializador.readObject();
        }catch(IOException | ClassNotFoundException e){
            System.out.println(e.getMessage());
        }
        
        return lista;
    }
    
    public void paraCadaElemento(Consumer<? super T> accion) {
        bestias.forEach(accion);
    }

}
